import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Room extends MapSite {
    private int _roomNumber;
    Map<Direction, MapSite> _sides;

    public Room(int RoomNo) {
        this._roomNumber = RoomNo;
        this._sides = new HashMap<>();
    }

    @Override
    public void Enter() {

    }

    @Override
    public void Print(int indent) {
        System.out.println("Room " + GetRoomNo() + ":");
        Arrays.asList(Direction.values())
                .forEach(direction -> {
                    if (this._sides.containsKey(direction)) {
                        PrintIndent.getInstance().PrintIndent(indent + 2);
                        System.out.printf("%-5s: ", direction);
                        this._sides.get(direction).Print(indent + 4);
                    }
                });
    }

    public int GetRoomNo() {
        return this._roomNumber;
    }

    public MapSite GetSide(Direction direction) {
        return this._sides.get(direction);
    }

    public void SetSIde(Direction direction, MapSite mapSite) {
        this._sides.put(direction, mapSite);
    }

}
