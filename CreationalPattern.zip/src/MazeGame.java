public class MazeGame {

    public Maze CreateMaze() {
        Maze maze = new Maze();
        Room r1 = new Room(1);
        Room r2 = new Room(2);
        Door door = new Door(r1, r2);

        maze.AddRoom(r1);
        maze.AddRoom(r2);

        r1.SetSIde(Direction.North, new Wall());
        r1.SetSIde(Direction.East, door);
        r1.SetSIde(Direction.South, new Wall());
        r1.SetSIde(Direction.West, new Wall());

        r2.SetSIde(Direction.North, new Wall());
        r2.SetSIde(Direction.East, new Wall());
        r2.SetSIde(Direction.South, new Wall());
        r2.SetSIde(Direction.West, door);

        return maze;
    }
}
