public class Wall extends MapSite {
    @Override
    public void Enter() {

    }

    @Override
    public void Print(int indent) {
        System.out.println("Wall");
    }
}
