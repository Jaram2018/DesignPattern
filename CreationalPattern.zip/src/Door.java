public class Door extends MapSite {
    private Room _room1;
    private Room _room2;
    private boolean isOpen;

    public Door(Room _room1, Room _room2) {
        this._room1 = _room1;
        this._room2 = _room2;
    }

    @Override
    public void Enter() {

    }

    @Override
    public void Print(int indent) {
        System.out.println("Door:");
        PrintIndent.getInstance().PrintIndent(indent);
        if (this._room1 != null) {
            System.out.printf("_room1 = %d\n", this._room1.GetRoomNo());
        } else {
            System.out.println("_room1 = NULL");
        }

        PrintIndent.getInstance().PrintIndent(indent);
        if (this._room2 != null) {
            System.out.printf("_room2 = %d\n", this._room2.GetRoomNo());
        } else {
            System.out.println("_room2 = NULL");
        }
    }

    public Room OtherSideFrom(Room room) {
        if (room == this._room1) {
            return this._room2;
        } else if (room == this._room2) {
            return this._room1;
        } else {
            return null;
        }
    }
}
