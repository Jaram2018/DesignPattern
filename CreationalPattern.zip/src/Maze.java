import java.util.LinkedList;
import java.util.List;

public class Maze implements MazeObject {
    private List<Room> _Rooms;

    public Maze() {
        this._Rooms = new LinkedList<>();
    }

    @Override
    public void Print(int indent) {
        PrintIndent.getInstance().PrintIndent(indent);
        System.out.println("Maze:");
        if (this._Rooms.isEmpty()) {
            PrintIndent.getInstance().PrintIndent(indent + 2);
            System.out.println("No Rooms");
        } else {
            this._Rooms.forEach(room -> {
                PrintIndent.getInstance().PrintIndent(indent + 2);
                room.Print(indent + 2);
            });
        }
    }

    public void AddRoom(Room room) {
        this._Rooms.add(room);
    }

    public Room RoomNo(int RoomNo) {
        return this._Rooms.stream().dropWhile(room -> room.GetRoomNo() != RoomNo).findFirst().orElse(null);
    }


}
