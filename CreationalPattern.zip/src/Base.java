public class Base {

    public static void main(String[] args) {
        MazeGame mazeGame = new MazeGame();
        Maze maze = mazeGame.CreateMaze();
        maze.Print(0);
    }
}
