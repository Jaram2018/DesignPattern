public interface MazeObject {

    void Print(int indent);
}
