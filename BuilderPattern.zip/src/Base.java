public class Base {

    public static void main(String[] args) {
        MazeGame mazeGame = new MazeGame();
        MazeBuilder builder = new CustomMazeBuilder();
        Maze maze = mazeGame.CreateMaze(builder);
        maze.Print(0);
    }
}
