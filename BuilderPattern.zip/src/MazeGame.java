public class MazeGame {

    public Maze CreateMaze(MazeBuilder builder) {
        return builder.buildBaseMaze().setNumOfRoom(2).buildDoor(1, 2).getMaze();
    }
}
