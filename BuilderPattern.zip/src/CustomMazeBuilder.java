
public class CustomMazeBuilder implements MazeBuilder<CustomMazeBuilder>{
	
	Maze maze;
	

	
	@Override
	public CustomMazeBuilder buildBaseMaze() {
		this.maze = new Maze();
		return this;
	}

	@Override
	public CustomMazeBuilder setNumOfRoom(int numOfRoom) {
		for(int i = 1; i <= numOfRoom; i++){
			Room room = new Room(i);
			this.maze.AddRoom(room);
		}
		return this;
	}

	@Override
	public CustomMazeBuilder buildDoor(int nRoom1, int nRoom2) {
		Room r1 = maze.RoomNo(nRoom1);
		Room r2 = maze.RoomNo(nRoom2);
		Door door = new Door(r1,r2);
		
		putDoorOnWall(r1,r2,door);
		return this;
	}
	
	private void putDoorOnWall(Room r1, Room r2, Door door){
		 r1.SetSIde(Direction.North, new Wall());
	     r1.SetSIde(Direction.East, door);
	     r1.SetSIde(Direction.South, new Wall());
	     r1.SetSIde(Direction.West, new Wall());

	     r2.SetSIde(Direction.North, new Wall());
	     r2.SetSIde(Direction.East, new Wall());
	     r2.SetSIde(Direction.South, new Wall());
	     r2.SetSIde(Direction.West, door);
	}

	@Override
	public Maze getMaze() {
		return maze;
	}
	

}
