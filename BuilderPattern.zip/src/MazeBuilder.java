
public interface MazeBuilder <T extends MazeBuilder<T>> {
	T buildBaseMaze();
	T setNumOfRoom(int numOfRoom);
	T buildDoor(int nRoom1, int nRoom2);
	Maze getMaze();
}
