public abstract class MapSite implements MazeObject {

    public abstract void Enter();

    @Override
    public abstract void Print(int indent);
}
