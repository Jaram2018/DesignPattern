public class PrintIndent {

    private static PrintIndent printIndent;
    public static PrintIndent getInstance() {
        if (printIndent == null) {
            printIndent = new PrintIndent();
        }
        return printIndent;
    }

    public void PrintIndent(int indent) {
        for (int i = 0; i < indent; i++) {
            System.out.print(" ");
        }
    }
}
